# Aura Parfum Buyurtmalar API

Bu loyiha xaridorlar sayti va admin saytini bitta buyurtmalar omboriga ulaydi. Netlify Blobs buyurtmalarni saqlaydi. Xaridor buyurtma yuboradi, admin esa ularni o‘qiydi va holatini o‘zgartiradi.

## 1. API’ni Netlify’ga joylash

1. Ushbu papkani yoki `aura-parfum-orders-api.zip` faylini Netlify’da **yangi, alohida loyiha** sifatida deploy qiling.
2. Deploy tugagach, Netlify → **Site configuration → Environment variables** joyiga quyidagilarni qo‘shing:

| Nomi | Qiymati |
| --- | --- |
| `ADMIN_LOGIN` | Admin login, masalan `admin` |
| `ADMIN_PASSWORD` | Kuchli parol tanlang |
| `AUTH_SECRET` | Uzun, tasodifiy maxfiy satr (kamida 32 belgi) |
| `ALLOWED_ORIGINS` | Xaridor va admin saytlari URL’lari, vergul bilan. Masalan: `https://aura-shop.netlify.app,https://aura-admin.netlify.app` |

3. Environment variables kiritilgandan keyin API loyihasini qayta deploy qiling.

API manzili quyidagicha bo‘ladi:

`https://SIZNING-API-SAYTINGIZ.netlify.app/.netlify/functions/orders`

## 2. Xaridorlar saytini ulash

Buyurtma yuboriladigan kod quyidagicha bo‘lishi kerak. `API_URL` o‘rniga 1-qadamdagi manzilni yozing.

```js
const API_URL = "https://SIZNING-API-SAYTINGIZ.netlify.app/.netlify/functions/orders";

async function sendOrder(order) {
  const response = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(order)
  });
  if (!response.ok) throw new Error("Buyurtma yuborilmadi");
  return response.json();
}
```

`order` ichida `customer` (`firstName`, `lastName`, `phone`, `address`, `comment`), `items` va `total` bo‘lishi kerak.

## 3. Admin panelni ulash

Admin avval API orqali kiradi; so‘ng token bilan buyurtmalarni oladi. Admin paroli brauzer kodida saqlanmaydi.

```js
const API_URL = "https://SIZNING-API-SAYTINGIZ.netlify.app/.netlify/functions/orders";

async function adminLogin(login, password) {
  const response = await fetch(`${API_URL}?action=login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ login, password })
  });
  if (!response.ok) throw new Error("Login yoki parol noto‘g‘ri");
  return response.json(); // token ni sessionStorage’da saqlang
}

async function getOrders(token) {
  const response = await fetch(API_URL, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!response.ok) throw new Error("Buyurtmalarni olish imkoni bo‘lmadi");
  return response.json();
}
```

Buyurtma holatini o‘zgartirish uchun API’ga `PATCH` so‘rov yuboring: `{ "id": "AP-XXXX", "status": "Qabul qilindi" }`.

## Muhim

- `ALLOWED_ORIGINS` ichiga faqat sizning ikki Netlify manzilingizni qo‘ying.
- `ADMIN_PASSWORD` va `AUTH_SECRET`ni hech kimga bermang, ularni HTML faylga yozmang.
- Bu API kichik do‘kon buyurtmalari uchun mos. To‘lov, mahsulotlar va ko‘p foydalanuvchili tizim uchun keyingi bosqichda haqiqiy ma’lumotlar bazasi ham qo‘shiladi.
