import { getStore } from "@netlify/blobs";

const store = getStore({ name: "aura-parfum-orders", consistency: "strong" });

function allowedOrigin(request) {
  const origin = request.headers.get("origin") || "";
  const allowed = (process.env.ALLOWED_ORIGINS || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  return allowed.includes(origin) ? origin : "";
}

function response(request, body, status = 200) {
  const origin = allowedOrigin(request);
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET, POST, PATCH, OPTIONS",
      "Vary": "Origin"
    }
  });
}

function base64Url(value) {
  return Buffer.from(value).toString("base64url");
}

async function hmac(value) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(process.env.AUTH_SECRET || ""),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value));
  return Buffer.from(signature).toString("base64url");
}

async function createToken() {
  const payload = base64Url(JSON.stringify({ role: "admin", exp: Date.now() + 12 * 60 * 60 * 1000 }));
  return `${payload}.${await hmac(payload)}`;
}

async function hasAdminAccess(request) {
  const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!token || !process.env.AUTH_SECRET) return false;
  const [payload, signature] = token.split(".");
  if (!payload || !signature || signature !== await hmac(payload)) return false;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    return data.role === "admin" && data.exp > Date.now();
  } catch {
    return false;
  }
}

function cleanText(value, max) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function validOrder(body) {
  const customer = body?.customer || {};
  if (!cleanText(customer.firstName, 80) || !cleanText(customer.lastName, 80)) return false;
  if (!cleanText(customer.phone, 40) || !cleanText(customer.address, 500)) return false;
  return Array.isArray(body?.items) && body.items.length > 0 && body.items.length <= 30;
}

export default async (request) => {
  if (request.method === "OPTIONS") return response(request, { ok: true });
  if (!allowedOrigin(request)) return response(request, { error: "Bu domen API uchun ruxsat berilmagan." }, 403);

  const url = new URL(request.url);
  const action = url.searchParams.get("action");

  if (request.method === "POST" && action === "login") {
    const body = await request.json().catch(() => ({}));
    const valid = body.login === process.env.ADMIN_LOGIN && body.password === process.env.ADMIN_PASSWORD;
    if (!valid || !process.env.AUTH_SECRET) return response(request, { error: "Login yoki parol noto‘g‘ri." }, 401);
    return response(request, { token: await createToken(), expiresIn: 43200 });
  }

  if (request.method === "POST") {
    const body = await request.json().catch(() => null);
    if (!validOrder(body)) return response(request, { error: "Buyurtma ma’lumotlari to‘liq emas." }, 400);
    const order = {
      id: `AP-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
      status: "Yangi",
      createdAt: new Date().toISOString(),
      customer: {
        firstName: cleanText(body.customer.firstName, 80),
        lastName: cleanText(body.customer.lastName, 80),
        phone: cleanText(body.customer.phone, 40),
        address: cleanText(body.customer.address, 500),
        comment: cleanText(body.customer.comment, 500)
      },
      items: body.items.slice(0, 30).map((item) => ({
        id: cleanText(String(item.id || ""), 80),
        name: cleanText(item.name, 160),
        price: Number.isFinite(Number(item.price)) ? Math.max(0, Number(item.price)) : 0,
        quantity: Math.min(99, Math.max(1, Number(item.quantity) || 1))
      })),
      total: Number.isFinite(Number(body.total)) ? Math.max(0, Number(body.total)) : 0
    };
    await store.setJSON(`orders/${order.id}.json`, order);
    return response(request, { order }, 201);
  }

  if (!(await hasAdminAccess(request))) return response(request, { error: "Admin ruxsati kerak." }, 401);

  if (request.method === "GET") {
    const { blobs } = await store.list({ prefix: "orders/" });
    const orders = (await Promise.all(blobs.map(({ key }) => store.get(key, { type: "json" })))).filter(Boolean);
    orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return response(request, { orders });
  }

  if (request.method === "PATCH") {
    const body = await request.json().catch(() => null);
    const id = cleanText(body?.id, 40);
    const status = cleanText(body?.status, 40);
    const permitted = ["Yangi", "Qabul qilindi", "Bajarildi", "Bekor qilindi"];
    if (!id || !permitted.includes(status)) return response(request, { error: "Buyurtma yoki holat noto‘g‘ri." }, 400);
    const key = `orders/${id}.json`;
    const order = await store.get(key, { type: "json" });
    if (!order) return response(request, { error: "Buyurtma topilmadi." }, 404);
    order.status = status;
    order.updatedAt = new Date().toISOString();
    await store.setJSON(key, order);
    return response(request, { order });
  }

  return response(request, { error: "Metod qo‘llab-quvvatlanmaydi." }, 405);
};
